# Minecraft Spoofer 
[![Build Status](https://travis-ci.com/egormkn/minecraft-spoofer.svg?token=4rLAZAP2mhXx56rkrerR&branch=master)](https://travis-ci.com/egormkn/minecraft-spoofer)

## Description

A tiny utility that modifies launch arguments for Minecraft launcher.

## Usage:

0) Download and install [Java](https://www.java.com/download/) and original [Minecraft launcher](https://www.minecraft.net/download).

1) Disable ur antivirus

2) Start the .bat